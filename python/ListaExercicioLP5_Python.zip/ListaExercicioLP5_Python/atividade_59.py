while True:
    n1 = float(input("Digite o primeiro número: "))
    n2 = float(input("Digite o segundo número: "))

    if n1 > n2:
        print("O primeiro número é maior que o segundo.")
        break

    print("O primeiro número precisa ser maior. Tente novamente.")
